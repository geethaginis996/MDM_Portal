sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/Sorter",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/ActionSheet",
    "sap/m/Button"
], function (Controller, Filter, FilterOperator, Sorter, JSONModel, MessageToast, ActionSheet, Button) {
    "use strict";

    return Controller.extend("mdm.portal.controller.FieldMaster", {

        onInit: function () {
            // Named JSON model that drives ALL filter dropdowns
            var oFiltersModel = new JSONModel({
                masterDataTypes : [],   // from /MasterDataTypes
                mainGroups      : [],   // from /FieldGroups (top-level only)
                displayTypes    : [],   // from /MetaDisplayTypes
                displayTypeMap  : {}    // code → label, used by table column
            });
            this.getView().setModel(oFiltersModel, "filters");

            // Load all three from backend in parallel
            this._loadMasterDataTypes(oFiltersModel);
            this._loadMainGroups(oFiltersModel);
            this._loadDisplayTypes(oFiltersModel);

            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("fieldMaster").attachPatternMatched(this._onRouteMatched, this);
        },

        _onRouteMatched: function () {
            var oTable   = this.byId("fieldTable");
            var oBinding = oTable.getBinding("items");
            if (oBinding) {
                oBinding.attachEventOnce("dataReceived", this._updateCount, this);
            }
        },

        _updateCount: function (oEvent) {
            var oTable = this.byId("fieldTable");
            var iCount = oEvent.getParameter("data")
                ? (oEvent.getParameter("data")["@odata.count"] || oTable.getItems().length)
                : oTable.getItems().length;
            this.byId("fieldCountBadge").setText(iCount + " fields");
        },

        // ── Load Master Data Types from /MasterDataTypes ──────────────
        _loadMasterDataTypes: function (oFiltersModel) {
            var oODataModel = this.getOwnerComponent().getModel();
            oODataModel
                .bindList("/MasterDataTypes", null, [new Sorter("sequence")])
                .requestContexts(0, Infinity)
                .then(function (aContexts) {
                    var aItems = [{ key: "", text: "All" }];
                    aContexts.forEach(function (oCtx) {
                        aItems.push({
                            key : oCtx.getProperty("master_data_type_id"),
                            text: oCtx.getProperty("description")
                        });
                    });
                    oFiltersModel.setProperty("/masterDataTypes", aItems);
                })
                .catch(function (oErr) {
                    MessageToast.show("Could not load Master Data Types: " + oErr.message);
                });
        },

        // ── Load Main Groups from /FieldGroups (top-level only) ───────
        _loadMainGroups: function (oFiltersModel) {
            var oODataModel = this.getOwnerComponent().getModel();
            // Top-level groups have no parent — filter where parent_group_id is null
            oODataModel
                .bindList("/FieldGroups", null, [new Sorter("sequence")])
                .requestContexts(0, Infinity)
                .then(function (aContexts) {
                    var aItems = [{ key: "", text: "All" }];
                    aContexts.forEach(function (oCtx) {
                        // Only top-level groups (no parent)
                        var sParent = oCtx.getProperty("parent_group_id_group_id");
                        if (!sParent) {
                            aItems.push({
                                key : oCtx.getProperty("group_id"),
                                text: oCtx.getProperty("description")
                            });
                        }
                    });
                    oFiltersModel.setProperty("/mainGroups", aItems);
                })
                .catch(function (oErr) {
                    MessageToast.show("Could not load Main Groups: " + oErr.message);
                });
        },

        // ── Load Display Types from /MetaDisplayTypes ─────────────────
        _loadDisplayTypes: function (oFiltersModel) {
            var oODataModel = this.getOwnerComponent().getModel();
            oODataModel
                .bindList("/MetaDisplayTypes", null, [new Sorter("sequence")])
                .requestContexts(0, Infinity)
                .then(function (aContexts) {
                    var aItems = [{ key: "", text: "All" }];
                    var oMap   = {};
                    aContexts.forEach(function (oCtx) {
                        var sKey  = oCtx.getProperty("display_type_id");
                        var sText = oCtx.getProperty("display_type_name");
                        aItems.push({ key: sKey, text: sText });
                        oMap[sKey] = sText;  // build lookup map for column
                    });
                    oFiltersModel.setProperty("/displayTypes", aItems);
                    oFiltersModel.setProperty("/displayTypeMap", oMap);
                })
                .catch(function (oErr) {
                    // Fallback: hardcode if MetaDisplayTypes not yet seeded
                    var aFallback = [
                        { key: "",            text: "All" },
                        { key: "FREE_INPUT",  text: "Free Input" },
                        { key: "DROPDOWN",    text: "Dropdown" },
                        { key: "SEARCH_HELP", text: "Search Help" },
                        { key: "CHECKBOX",    text: "Checkbox" },
                        { key: "DATEPICKER",  text: "Date Picker" }
                    ];
                    var oFallbackMap = {
                        FREE_INPUT:  "Free Input",
                        DROPDOWN:    "Dropdown",
                        SEARCH_HELP: "Search Help",
                        CHECKBOX:    "Checkbox",
                        DATEPICKER:  "Date Picker"
                    };
                    oFiltersModel.setProperty("/displayTypes", aFallback);
                    oFiltersModel.setProperty("/displayTypeMap", oFallbackMap);
                    MessageToast.show("Display types loaded from defaults");
                });
        },

        // ── Filters ───────────────────────────────────────────────────
        onFilterLiveChange: function () {
            this._applyFilters();
        },

        onFilterChange: function () {
            // Selections ready; user presses Go to apply
        },

        onGo: function () {
            this._applyFilters();
        },

        _applyFilters: function () {
            var sSearch     = this.byId("filterSearch").getValue();
            var sMDT        = this.byId("filterMasterDataType").getSelectedKey();
            var sMainGroup  = this.byId("filterMainGroup").getSelectedKey();
            var sDispType   = this.byId("filterDisplayType").getSelectedKey();
            var sActive     = this.byId("filterActive").getSelectedKey();

            var aFilters = [];

            if (sSearch) {
                aFilters.push(new Filter({
                    filters: [
                        new Filter("field_id",    FilterOperator.Contains, sSearch),
                        new Filter("description", FilterOperator.Contains, sSearch)
                    ],
                    and: false
                }));
            }

            if (sMDT) {
                aFilters.push(new Filter("master_data_type_id", FilterOperator.EQ, sMDT));
            }

            if (sMainGroup) {
                aFilters.push(new Filter("main_group_group_id", FilterOperator.EQ, sMainGroup));
            }

            if (sDispType) {
                aFilters.push(new Filter("display_type", FilterOperator.EQ, sDispType));
            }

            if (sActive !== "") {
                aFilters.push(new Filter("active", FilterOperator.EQ, sActive === "true"));
            }

            var oBinding = this.byId("fieldTable").getBinding("items");
            oBinding.filter(
                aFilters.length ? [new Filter({ filters: aFilters, and: true })] : []
            );
            oBinding.attachEventOnce("dataReceived", this._updateCount, this);
        },

        onClearFilters: function () {
            this.byId("filterSearch").setValue("");
            this.byId("filterMasterDataType").setSelectedKey("");
            this.byId("filterMainGroup").setSelectedKey("");
            this.byId("filterDisplayType").setSelectedKey("");
            this.byId("filterActive").setSelectedKey("");
            var oBinding = this.byId("fieldTable").getBinding("items");
            oBinding.filter([]);
            oBinding.attachEventOnce("dataReceived", this._updateCount, this);
        },

        onAdaptFilters: function () {
            MessageToast.show("Adapt Filters — coming soon!");
        },

        // ── Navigation ────────────────────────────────────────────────
        onFieldLinkPress: function (oEvent) {
            oEvent.stopPropagation();
            var oCtx = oEvent.getSource().getBindingContext();
            if (!oCtx) return;
            this.getOwnerComponent().getRouter().navTo("fieldMasterDetail", {
                fieldId: encodeURIComponent(oCtx.getProperty("field_id"))
            });
        },

        onRowPress: function (oEvent) {
            var oCtx = oEvent.getSource().getBindingContext();
            if (!oCtx) return;
            this.getOwnerComponent().getRouter().navTo("fieldMasterDetail", {
                fieldId: encodeURIComponent(oCtx.getProperty("field_id"))
            });
        },

        onRowMenuPress: function (oEvent) {
            oEvent.stopPropagation();
            var oButton = oEvent.getSource();
            if (!this._oActionSheet) {
                this._oActionSheet = new ActionSheet({
                    buttons: [
                        new Button({ text: "Edit",       icon: "sap-icon://edit",    press: function () { MessageToast.show("Edit"); } }),
                        new Button({ text: "Duplicate",  icon: "sap-icon://copy",    press: function () { MessageToast.show("Duplicate"); } }),
                        new Button({ text: "Deactivate", icon: "sap-icon://decline", press: function () { MessageToast.show("Deactivate"); } })
                    ]
                });
                this.getView().addDependent(this._oActionSheet);
            }
            this._oActionSheet.openBy(oButton);
        },

        onAdd: function () {
            this.getOwnerComponent().getRouter().navTo("fieldMasterDetail", {
                fieldId: "NEW"
            });
        },

        onExport: function () {
            MessageToast.show("Export started");
        },

        onImport: function () {
            MessageToast.show("Import — coming soon!");
        }
    });
});
