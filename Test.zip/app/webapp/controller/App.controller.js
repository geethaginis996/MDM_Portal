sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";

    return Controller.extend("mdm.portal.controller.App", {

        onAfterRendering: function () {
            this.getOwnerComponent().getRouter().navTo("fieldMaster");
        },

        onMenuToggle: function () {
            var oSplit = this.byId("splitContainer");
            if (oSplit.isMasterShown()) {
                oSplit.hideMaster();
            } else {
                oSplit.showMaster();
            }
        },

        onNavSelect: function (oEvent) {
            var oItem  = oEvent.getParameter("listItem");
            var sTitle = oItem.getTitle();

            var mRoutes = {
                "Field Master"      : "fieldMaster",
                "BP Roles"          : "bpRoles"
            };

            var sRoute = mRoutes[sTitle];
            if (sRoute) {
                this.getOwnerComponent().getRouter().navTo(sRoute);
            } else {
                sap.m.MessageToast.show(sTitle + " — coming soon!");
            }
        }
    });
});