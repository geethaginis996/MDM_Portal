sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/format/DateFormat"
], function (Controller, JSONModel, MessageToast, MessageBox, DateFormat) {
    "use strict";

    var oDateFmt = DateFormat.getDateTimeInstance({ style: "medium" });

    return Controller.extend("mdm.portal.controller.FieldMasterDetail", {

        // ── Lifecycle ─────────────────────────────────────────────────

        onInit: function () {
            // Local view model for UI state (dirty flag, selected tab, etc.)
            this._oViewModel = new JSONModel({
                busy:       false,
                isNew:      false,
                isDirty:    false,
                selectedTab: "general",
                selectedValueTable:   null,
                selectedValidation:   null
            });
            this.getView().setModel(this._oViewModel, "view");

            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("fieldMasterDetail").attachPatternMatched(this._onRouteMatched, this);
        },

        _onRouteMatched: function (oEvent) {
            var sFieldId = decodeURIComponent(oEvent.getParameter("arguments").fieldId);

            if (sFieldId === "NEW") {
                this._createNewField();
            } else {
                this._bindField(sFieldId);
            }
        },

        // ── Binding ───────────────────────────────────────────────────

        _bindField: function (sFieldId) {
            this._oViewModel.setProperty("/isNew", false);
            this._oViewModel.setProperty("/busy", true);

            // Bind with expansions for association fields
            var sPath = "/FieldMasters('" + sFieldId + "')";
            this.getView().bindObject({
                path: sPath,
                parameters: {
                    $expand: "main_group,sub_group,value_table,validation"
                },
                events: {
                    dataReceived: function (oEvent) {
                        this._oViewModel.setProperty("/busy", false);
                        var oData = oEvent.getParameter("data");
                        if (!oData) {
                            MessageToast.show("Field not found");
                            this.onNavBack();
                            return;
                        }
                        this._updateHeader(oData);
                        this._updateValidationPreview(oData.validation);
                        this._updateValueTablePreview(oData.value_table);
                        this._loadSubGroups(oData.main_group_group_id);
                    }.bind(this)
                }
            });
        },

        _createNewField: function () {
            this._oViewModel.setProperty("/isNew", true);
            this._oViewModel.setProperty("/busy", false);

            // Create a transient entry on the OData model
            var oModel  = this.getView().getModel();
            var oListBinding = oModel.bindList("/FieldMasters");
            var oContext = oListBinding.create({
                field_id:     "",
                description:  "",
                data_type:    "CHAR",
                length:       10,
                decimals:     null,
                display_type: "FREE_INPUT",
                active:       true,
                source_table: "",
                source_field: ""
            });
            this.getView().setBindingContext(oContext);
            this._updateHeader({ field_id: "New Field", description: "" });
        },

        // ── Header helpers ────────────────────────────────────────────

        _updateHeader: function (oData) {
            var sTitle = oData.field_id
                ? oData.field_id + (oData.description ? " — " + oData.description : "")
                : "New Field";
            this.byId("fieldTitle").setText(sTitle);
            this.byId("pageTitle").setText(sTitle);

            this.byId("attrStatus").setText(oData.active ? "Active" : "Inactive");
            this.byId("attrCreated").setText(oData.createdBy || "—");
            this.byId("attrDate").setText(
                oData.createdAt ? oDateFmt.format(new Date(oData.createdAt)) : "—"
            );
            this.byId("attrModified").setText(
                oData.modifiedAt ? oDateFmt.format(new Date(oData.modifiedAt)) : "—"
            );
        },

        // ── Tab 2: Grouping — load sub groups when main group changes ──

        onMainGroupChange: function (oEvent) {
            var sGroupId = oEvent.getSource().getSelectedKey();
            this._loadSubGroups(sGroupId);
        },

        _loadSubGroups: function (sMainGroupId) {
            if (!sMainGroupId) return;

            var oModel   = this.getView().getModel();
            var oSubSel  = this.byId("selSubGroup");
            var oBinding = oModel.bindList("/FieldGroups", null, null, [
                new (sap.ui.require("sap/ui/model/Filter"))(
                    "parent_group_id_group_id", "EQ", sMainGroupId
                )
            ]);
            oBinding.requestContexts().then(function (aContexts) {
                var aItems = aContexts.map(function (oCtx) {
                    return new sap.ui.core.Item({
                        key:  oCtx.getProperty("group_id"),
                        text: oCtx.getProperty("group_id") + " — " + oCtx.getProperty("description")
                    });
                });
                oSubSel.destroyItems();
                aItems.forEach(function (oItem) { oSubSel.addItem(oItem); });
            });
        },

        // ── Tab 3: Value Help — show preview of linked value table ────

        onValueTableChange: function (oEvent) {
            var sKey = oEvent.getSource().getSelectedKey();
            this._updateValueTablePreview(sKey ? { value_table_id: sKey } : null);
        },

        _updateValueTablePreview: function (oVT) {
            if (!oVT || !oVT.value_table_id) {
                this.byId("vtSource").setText("—");
                this.byId("vtOutputKey").setText("—");
                this.byId("vtOutputDesc").setText("—");
                return;
            }
            // If we already have expanded data use it, otherwise fetch
            if (oVT.source_table) {
                this.byId("vtSource").setText(oVT.source_table);
                this.byId("vtOutputKey").setText(oVT.output_key || "—");
                this.byId("vtOutputDesc").setText(oVT.output_desc || "—");
            } else {
                var oModel = this.getView().getModel();
                oModel.bindContext("/ValueTables('" + oVT.value_table_id + "')").requestObject().then(function (oData) {
                    this.byId("vtSource").setText(oData.source_table || "—");
                    this.byId("vtOutputKey").setText(oData.output_key || "—");
                    this.byId("vtOutputDesc").setText(oData.output_desc || "—");
                }.bind(this));
            }
        },

        // ── Tab 4: Validation — show rule details when one is chosen ──

        onValidationChange: function (oEvent) {
            var sKey = oEvent.getSource().getSelectedKey();
            if (!sKey) {
                this._clearValidationPreview();
                return;
            }
            var oModel = this.getView().getModel();
            oModel.bindContext("/ValidationRules('" + sKey + "')").requestObject().then(function (oData) {
                this._updateValidationPreview(oData);
            }.bind(this));
        },

        _updateValidationPreview: function (oRule) {
            if (!oRule) { this._clearValidationPreview(); return; }
            this.byId("valFnName").setText(oRule.function_name || "—");
            this.byId("valDesc").setText(oRule.description || "—");
            this.byId("valParam1").setText(oRule.input_param_1 || "—");
            this.byId("valParam2").setText(oRule.input_param_2 || "—");
            this.byId("valParam3").setText(oRule.input_param_3 || "—");
            this.byId("valErrMsg").setText(oRule.error_message || "—");
        },

        _clearValidationPreview: function () {
            ["valFnName","valDesc","valParam1","valParam2","valParam3","valErrMsg"]
                .forEach(function (sId) { this.byId(sId).setText("—"); }.bind(this));
        },

        // ── Tab 5: Usage — navigate to role detail on row press ───────

        onUsageRowPress: function (oEvent) {
            var oCtx   = oEvent.getSource().getBindingContext();
            var sRoleId = oCtx.getProperty("role/role_id");
            if (sRoleId) {
                this.getOwnerComponent().getRouter().navTo("bpRoleDetail", {
                    roleId: encodeURIComponent(sRoleId)
                });
            }
        },

        // ── Save ──────────────────────────────────────────────────────

        onSave: function () {
            var oModel = this.getView().getModel();

            // Basic validation
            var sFieldId = this.byId("inFieldId").getValue().trim();
            var sDesc    = this.byId("inDescription").getValue().trim();

            if (!sFieldId) {
                MessageBox.error("Field ID is required.");
                return;
            }
            if (!sDesc) {
                MessageBox.error("Description is required.");
                return;
            }

            this._oViewModel.setProperty("/busy", true);

            oModel.submitBatch("fieldMasterUpdate").then(function () {
                this._oViewModel.setProperty("/busy", false);
                this._oViewModel.setProperty("/isDirty", false);
                MessageToast.show("Field saved successfully");
            }.bind(this)).catch(function (oErr) {
                this._oViewModel.setProperty("/busy", false);
                MessageBox.error("Save failed: " + (oErr.message || "Unknown error"));
            }.bind(this));
        },

        onCancel: function () {
            if (this._oViewModel.getProperty("/isDirty")) {
                MessageBox.confirm("Discard unsaved changes?", {
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            this.getView().getModel().resetChanges();
                            this.onNavBack();
                        }
                    }.bind(this)
                });
            } else {
                this.onNavBack();
            }
        },

        onCopy: function () {
            MessageToast.show("Field copied — edit ID before saving");
        },

        // ── Tab bar ───────────────────────────────────────────────────

        onTabSelect: function (oEvent) {
            var sKey = oEvent.getParameter("key");
            this._oViewModel.setProperty("/selectedTab", sKey);

            // Refresh usage count when switching to usage tab
            if (sKey === "usage") {
                var oUsageTable = this.byId("usageTable");
                if (oUsageTable && oUsageTable.getBinding("items")) {
                    oUsageTable.getBinding("items").requestContexts().then(function (aCtx) {
                        this.byId("usageCount").setText(aCtx.length + " role assignments");
                    }.bind(this));
                }
            }

            // Load audit log only when changelog tab is opened
            if (sKey === "changelog") {
                this._loadChangeLog();
            }
        },

        _loadChangeLog: function () {
            var oCtx     = this.getView().getBindingContext();
            var sFieldId = oCtx ? oCtx.getProperty("field_id") : null;
            if (!sFieldId) return;

            var oTable   = this.byId("logTable");
            var oBinding = oTable.getBinding("items");
            if (!oBinding) return;

            // Filter AuditLogs by entity_name = FieldMaster and entity_key = fieldId
            var Filter = sap.ui.require("sap/ui/model/Filter");
            oBinding.filter([
                new Filter("entity_name", "EQ", "FieldMaster"),
                new Filter("entity_key",  "EQ", sFieldId)
            ]);
            oBinding.resume(); // was suspended — now activate
        },

        // ── Navigation ────────────────────────────────────────────────

        onNavBack: function () {
            this.getOwnerComponent().getRouter().navTo("fieldMaster");
        },

        onNavHome: function () {
            this.getOwnerComponent().getRouter().navTo("masterDataTypes");
        }
    });
});